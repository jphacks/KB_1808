exports.handler = async (event, context, callback) => {

    // パラメータチェック
    if(event['temperature'] == undefined || event['temperature'] == undefined){
        callback(JSON.stringify(getErrorObj(context, getErrorMessageParameterNotFound())));
    }

    if(typeof event['temperature'] != 'number'){
        callback(JSON.stringify(getErrorObj(context, getErrorMessageParameterNotNumber())));
    }

    const responseObj = {
        "ratio" : getRario(event['temperature'], 30, 40)
    };

    const response = {
        statusCode: 200,
        body: JSON.stringify(responseObj)
    };
    
    return response;
};

function getErrorObj(context, message){
    return {
        "statusCode" : 400,
        "requestId" : context.awsRequestId,
        "message" : message
    };
}

function getErrorMessageParameterNotFound(){
    return "Parameter ['temperature'] dosn't found.";
}

function getErrorMessageParameterNotNumber(){
    return "Parameter ['temperature'] isn't Number.";
}

function getRario(temperature, width, target){

    if(temperature > width + target){
        return 100;
    }
    if(temperature < width - target){
        return 0;
    }
    return (temperature - target) / width * 100;
}